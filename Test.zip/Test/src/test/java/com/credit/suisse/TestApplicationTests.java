package com.credit.suisse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import helpers.DAOTest;
import helpers.ParserTest;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DAOTest.class,ParserTest.class})
public class TestApplicationTests {

	@Test
	public void contextLoads() {
		
	}

}
