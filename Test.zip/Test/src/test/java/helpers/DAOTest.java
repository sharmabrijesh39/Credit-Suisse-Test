package helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.credit.suisse.TestApplicationTests;
import com.credit.suisse.app.bean.EventBean;
import com.credit.suisse.app.dao.EventDetailsDao;
import com.credit.suisse.app.dao.EventDetailsDaoImpl;

public class DAOTest extends TestApplicationTests{

	@InjectMocks
	private EventDetailsDaoImpl dao;
	@Mock
	private Connection mockConnection;
	@Mock
	private Statement mockStatement;
	@Mock
	private PreparedStatement mockPreparedStatement;
	@Mock
	private ResultSet mockResultSet;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void createEventsTable() throws SQLException {
		Mockito.when(mockConnection.createStatement()).thenReturn(mockStatement);
		Mockito.when(mockConnection.createStatement().executeUpdate(Mockito.anyString())).thenReturn(1);
		dao.createLogEventInfoTable();
		Mockito.verify(mockConnection.createStatement(), Mockito.calls(1));
	}

	@Test
	public void writeEvent() throws SQLException {
		Mockito.when(mockConnection.prepareStatement(Mockito.anyString())).thenReturn(mockPreparedStatement);
		Mockito.when(mockPreparedStatement.executeUpdate()).thenReturn(1);

		EventBean event = new EventBean.Builder("test", 2, false).withHost(null).withType(null).build();
		dao.insertDataEvent(event);

		Mockito.verify(mockConnection.prepareStatement(Mockito.anyString()), Mockito.calls(1));
	}

	@Test
	public void selectAll() throws SQLException {
		Mockito.when(mockConnection.createStatement()).thenReturn(mockStatement);
		Mockito.when(mockStatement.executeQuery(Mockito.anyString())).thenReturn(mockResultSet);
		Mockito.when(mockResultSet.next()).thenReturn(true);
		Mockito.when(mockResultSet.getBoolean(Mockito.anyString())).thenReturn(true);

		dao.fetchAllRows();
		Mockito.verify(mockConnection.createStatement(), Mockito.times(1));
	}

//    @Test
//    public void deleteAll() throws SQLException {
//        Mockito.when(mockConnection.createStatement()).thenReturn(mockStatement);
//        Mockito.when(mockStatement.executeUpdate(Mockito.anyString())).thenReturn(1);
//
//        dao.deleteAll();
//
//        Mockito.verify(mockConnection.createStatement(), Mockito.times(1));
//    }

	@Test
	public void closeDatabase() throws SQLException {
		dao.closeDatabase();

		Mockito.verify(mockConnection.createStatement(), Mockito.calls(1));;
	}
}
