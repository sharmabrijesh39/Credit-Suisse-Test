package com.credit.suisse.app.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.stereotype.Component;

import com.credit.suisse.app.bean.EventBean;
import com.credit.suisse.app.constant.AppConstants;

/**
 * @author Birjesh Sharma
 *
 */

@Component
public class EventDetailsDaoImpl implements EventDetailsDao {
	private static final Log logger = LogFactory.getLog(EventDetailsDaoImpl.class);

	private static final String TABLENAME = "LogEventInfo";

	@Value("${hsql.db.connection}")
	private String connectionInfo;

	@Value("${hsql.db.username}")
	private String userName;

	@Value("${hsql.db.password}")
	private String password;

	private static Connection connection;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	public EventDetailsDaoImpl() throws SQLException {

		logger.info("create DB connection");
		connection = DriverManager.getConnection(AppConstants.DB_URL, AppConstants.USERNAME, AppConstants.PASSWORD);
	}

	@Override
	public void createLogEventInfoTable() throws SQLException {

		String createTableSqlQuery = "CREATE TABLE IF NOT EXISTS " + TABLENAME
				+ " (ID VARCHAR(100) NOT NULL, DURATION FLOAT NOT NULL, "
				+ " TYPE VARCHAR(150), HOST VARCHAR(50), ALERT BOOLEAN NOT NULL)";

		logger.info("Creating LogEventInfo table in HSQL DB if table does not exist");
		connection.createStatement().executeUpdate(createTableSqlQuery);
	}

	@Override
	public void insertDataEvent(EventBean event) throws SQLException {
		String insertDataSqlQuery = "INSERT INTO " + TABLENAME
				+ " (ID, DURATION, TYPE, HOST, ALERT)  VALUES (?, ?, ?, ?, ?)";

		PreparedStatement preparedStatement = connection.prepareStatement(insertDataSqlQuery);
		preparedStatement.setString(1, event.getId());
		preparedStatement.setFloat(2, event.getDuration());
		preparedStatement.setString(3, event.getType());
		preparedStatement.setString(4, event.getHost());
		preparedStatement.setBoolean(5, event.isAlert());

		preparedStatement.executeUpdate();
	}

	@Override
	public void closeDatabase() throws SQLException {
		logger.info("Closing database connection.");
		connection.close();
	}

	@Override
	public void fetchAllRows() throws SQLException {
		String fetchAllDataSqlQuery = "SELECT * FROM " + TABLENAME;

		logger.debug("fetching all the data from Table");
		ResultSet resultSet = connection.createStatement().executeQuery(fetchAllDataSqlQuery);

		while (resultSet.next()) {
			if (resultSet.getBoolean(5)) {
				logger.debug("Alert for taking taking longer than 4ms where eventId =" + resultSet.getString(1));
			}
		}
	}

	public void deleteAllRows() throws SQLException {
		String deleteTableSqlQuery = "DELETE FROM " + TABLENAME;

		logger.warn("deleting all rows from table");
		connection.createStatement().executeUpdate(deleteTableSqlQuery);
	}
}
