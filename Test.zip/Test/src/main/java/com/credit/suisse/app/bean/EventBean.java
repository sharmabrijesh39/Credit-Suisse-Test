package com.credit.suisse.app.bean;

/**
 * @author Birjesh Sharma
 *
 */

public class EventBean {

	private String id;
	private long duration;
	private boolean alert;
	private String type;
	private String host;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the duration
	 */
	public long getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(long duration) {
		this.duration = duration;
	}

	/**
	 * @return the alert
	 */
	public boolean isAlert() {
		return alert;
	}

	/**
	 * @param alert the alert to set
	 */
	public void setAlert(boolean alert) {
		this.alert = alert;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	public static class Builder {
		
		private final String id;
		private final long duration;
		private final boolean alert;
		private String type;
		private String host;

		public Builder(String id, long duration, boolean alert) {
			this.id = id;
			this.duration = duration;
			this.alert = alert;
		}

		public Builder withType(String type) {
			this.type = type;
			return this;
		}

		public Builder withHost(String host) {
			this.host = host;
			return this;
		}

		public EventBean build() {
			EventBean event = new EventBean();
			event.alert = this.alert;
			event.duration = this.duration;
			event.type = this.type;
			event.host = this.host;
			event.id = this.id;
			return event;
		}
	}

}
