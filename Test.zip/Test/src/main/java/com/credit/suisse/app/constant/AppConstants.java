/**
 * 
 */
package com.credit.suisse.app.constant;

/**
 * @author Birjesh Sharma
 *
 */
public class AppConstants {
	
	public static final String DB_URL="jdbc:hsqldb:file:hsqldb/logs";
	public static final String USERNAME="SA";
	public static final String PASSWORD="";

}
