package com.credit.suisse.app.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;

import com.credit.suisse.app.bean.AppServerBean;
import com.credit.suisse.app.bean.EventBean;
import com.google.gson.Gson;

/**
 * @author Birjesh Sharma
 *
 */
public class LogDaoImpl implements LogDao {
	public void parseLogs(BufferedReader reader, EventDetailsDao dao) throws IOException, SQLException {
		HashMap<String, AppServerBean> eventDataMap = new HashMap<>();
		Gson gson = new Gson();
		String line = "";
		while (reader.readLine() != null) {
			line = reader.readLine();
			AppServerBean appServerBean = gson.fromJson(line, AppServerBean.class);
			String eventId = appServerBean.getId();
			if (!eventDataMap.containsKey(eventId)) {
				eventDataMap.put(eventId, appServerBean);
				continue;
			}

			AppServerBean oldAppServerBean = eventDataMap.remove(eventId);
			long duration = Math.abs(appServerBean.getTimestamp() - oldAppServerBean.getTimestamp());
			boolean alert = false;
			if (duration > 4) {
				alert = true;
			}

			EventBean event = new EventBean.Builder(eventId, duration, alert).withHost(appServerBean.getHost())
					.withType(appServerBean.getType()).build();
			dao.insertDataEvent(event);
		}
	}
}
