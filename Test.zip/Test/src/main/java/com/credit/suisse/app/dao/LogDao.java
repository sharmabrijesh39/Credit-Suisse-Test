/**
 * 
 */
package com.credit.suisse.app.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author Birjesh Sharma
 *
 */
public interface LogDao {

	void parseLogs(BufferedReader reader, EventDetailsDao dao) throws IOException, SQLException;

}
