package com.credit.suisse.app;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import com.credit.suisse.app.dao.EventDetailsDao;
import com.credit.suisse.app.dao.EventDetailsDaoImpl;
import com.credit.suisse.app.dao.LogDao;
import com.credit.suisse.app.dao.LogDaoImpl;

/**
 * @author Birjesh Sharma
 *
 */

@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@ComponentScan(basePackages = { "com.credit.suisse" })
@PropertySource({ "classpath:application.properties" })
public class LogController {

	private final static Log logger = LogFactory.getLog(LogController.class);


	public static void main(String[] args) {

		SpringApplication.run(LogController.class, args);

		if (args == null || args.length != 1) {
			logger.error("No file path specified");
			throw new IllegalArgumentException("Please pass the file path.");
		}

		try {
			BufferedReader reader = new BufferedReader(new FileReader(args[0]));
			EventDetailsDao dao = new EventDetailsDaoImpl();
			dao.createLogEventInfoTable();

			logger.debug("Reading data from the file");
			LogDao parser = new LogDaoImpl();
			parser.parseLogs(reader, dao);

			dao.fetchAllRows();
			// dao.deleteAllRows();
			dao.closeDatabase();
		} catch (IOException e) {
			logger.error("Error while reading and parsing the file" + e);
		} catch (SQLException e) {
			logger.error("Error encountered with DB" + e);
		}
	}
}
