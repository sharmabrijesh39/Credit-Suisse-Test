/**
 * 
 */
package com.credit.suisse.app.dao;

import java.sql.SQLException;

import com.credit.suisse.app.bean.EventBean;

/**
 * @author Birjesh Sharma
 *
 */
public interface EventDetailsDao {

	void createLogEventInfoTable() throws SQLException;
	
	void insertDataEvent(EventBean event) throws SQLException;
	
	void fetchAllRows() throws SQLException;

	void closeDatabase() throws SQLException;
}
