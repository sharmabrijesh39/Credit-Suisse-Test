package com.credit.suisse.app.bean;

/**
 * @author Birjesh Sharma
 *
 */

public class AppServerBean {
    
    private String id;
    private String state;
    private long timestamp;
    private String host;
    private String type;

    /**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the timestamp
	 */
	public long getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * @return the host
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(String host) {
		this.host = host;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "AppServerBean [id=" + id + ", state=" + state + ", timestamp=" + timestamp + ", host=" + host
				+ ", type=" + type + "]";
	}


    public static class Builder {
        private final String id;
        private final long timestamp;
        private final String state;
        private String host;
        private String type;

        public Builder(String id, long timestamp, String state) {
            this.id = id;
            this.timestamp = timestamp;
            this.state = state;
        }

        public Builder withType(String type) {
            this.type = type;
            return this;
        }

        public Builder withHost(String host) {
            this.host = host;
            return this;
        }

        public AppServerBean build() {
        	AppServerBean appServerBean = new AppServerBean();
            appServerBean.id = this.id;
            appServerBean.timestamp = this.timestamp;
            appServerBean.type = this.type;
            appServerBean.host = this.host;
            appServerBean.state = this.state;
            return appServerBean;
        }
    }
}
